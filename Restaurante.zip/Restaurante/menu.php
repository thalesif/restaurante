<!DOCTYPE html>
<html>
<head>
    <title>Menu do Usuário</title>
    
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<style>
    .menu {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
    }

    .user-info {
        position: relative;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #FFFFFF;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: #333333;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #f2f2f2;
    }

    .user-info:hover .dropdown-content {
        display: block;
    }

    .logout-button, .signup-button {
        background-color: #FF5733;
        color: #FFFFFF;
        border: none;
        padding: 10px 20px;
        cursor: pointer;
        border-radius: 5px;
    }

    .logout-button:hover, .signup-button:hover {
        background-color: #D43F00;
    }

    .logout-button {
        margin-right: auto; /* Coloca o botão "Sair" à esquerda */
    }

    .signup-button {
        margin-left: auto; /* Coloca o botão "Cadastrar Produto" à direita */
    }
</style>

<div class="menu">
    <div class="user-info dropdown">
        <div class="dropdown-content">
            <!-- Conteúdo do dropdown -->
            <a class="dropdown-item" href="cadastrar-produto.php">Cadastrar Produto</a>
            <a class="dropdown-item" href="#" onclick="logout()">Sair</a>
        </div>
    </div>
    <button class="logout-button" onclick="logout()">Sair</button>
    <a href="cadastrar-produto.php" class="signup-button">Cadastrar Produto</a>
</div>

    <script>
        function logout() {
        // Aqui você pode adicionar lógica para encerrar a sessão, por exemplo:
        // session_start();
        <?php session_destroy(); ?>

        // Redireciona para a página de login
        window.location.href = 'login.php';
    }
    </script>
</body>
</html>
